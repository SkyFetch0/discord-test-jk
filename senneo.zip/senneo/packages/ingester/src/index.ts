import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import { Kafka, Consumer, EachBatchPayload } from 'kafkajs';
import { ClickHouseClient } from '@clickhouse/client';
import { RawMessage } from '@senneo/shared';
import { createClickHouseClient, writeMessages as clickhouseWrite } from './clickhouse';

function envPositiveInt(name: string, defaultValue: number): number {
  const parsed = parseInt(process.env[name] ?? `${defaultValue}`, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : defaultValue;
}

const KAFKA_BROKERS    = process.env.KAFKA_BROKERS  ?? 'localhost:9092';
const KAFKA_TOPIC      = process.env.KAFKA_TOPIC    ?? 'messages';
const KAFKA_DLQ_TOPIC  = `${KAFKA_TOPIC}.dlq`;      // Dead-letter queue topic
const KAFKA_GROUP      = 'senneo-ingester';
const KAFKA_REPLICATION_FACTOR = envPositiveInt('KAFKA_REPLICATION_FACTOR', 1);
const TARGET_TOPIC_PARTITIONS = envPositiveInt('KAFKA_PARTITIONS', 16);
const BATCH_FLUSH_SIZE = envPositiveInt('INGESTER_BATCH_FLUSH_SIZE', 2_000);
const CONSUMER_MAX_BYTES = envPositiveInt('INGESTER_MAX_BYTES', 100 * 1024 * 1024);
const CONSUMER_MAX_BYTES_PER_PARTITION = envPositiveInt('INGESTER_MAX_BYTES_PER_PARTITION', 8 * 1024 * 1024);
const CONSUMER_MIN_BYTES = envPositiveInt('INGESTER_MIN_BYTES', 1);
const CONSUMER_MAX_WAIT_TIME_MS = envPositiveInt('INGESTER_MAX_WAIT_TIME_MS', 250);
const PARTITIONS_CONSUMED_CONCURRENTLY = envPositiveInt('INGESTER_PARTITIONS_CONSUMED_CONCURRENTLY', 8);

// ── Sampled error logging (Task 4: prevent log flood on sustained errors) ────
const _lastLogTs: Record<string, number> = {};
const LOG_SAMPLE_MS = 10_000; // At most 1 log per key per 10s
function logSampled(key: string, level: 'error' | 'warn', ...args: unknown[]): void {
  const now = Date.now();
  if (now - (_lastLogTs[key] ?? 0) < LOG_SAMPLE_MS) return;
  _lastLogTs[key] = now;
  console[level](...args);
}

// ── Error log reporter (writes to CH error_log, sampled to prevent flood) ────
const CH_DB_NAME = process.env.CLICKHOUSE_DB ?? 'senneo_operations';
const _lastErrorLogTs: Record<string, number> = {};
function reportError(
  ch: ClickHouseClient, category: string, severity: string, message: string, err?: unknown,
): void {
  const fp = `ingester:${category}`;
  const now = Date.now();
  if (now - (_lastErrorLogTs[fp] ?? 0) < LOG_SAMPLE_MS) return;
  _lastErrorLogTs[fp] = now;
  const detail = err instanceof Error ? `${err.message}\n${err.stack ?? ''}`.slice(0, 4096) : String(err ?? '').slice(0, 4096);
  ch.insert({
    table: `${CH_DB_NAME}.error_log`,
    values: [{ ts: new Date().toISOString().replace('T', ' ').replace('Z', ''), severity, category, source: 'ingester', message: message.slice(0, 2000), detail, fingerprint: fp }],
    format: 'JSONEachRow',
  }).catch(() => {}); // best-effort — don't throw on error-log write failure
}

// ── Metrics (in-memory, exposed via /metrics endpoint) ──────────────────────
const metrics = {
  msgsProcessed:  0,
  msgsFailedDlq:  0,
  batchesFlushed: 0,
  chErrors:       0,
  startedAt:      new Date().toISOString(),
};

const METRICS_FILE = path.resolve(process.cwd(), 'ingester_metrics.json');
function flushMetrics(): void {
  try { fs.writeFileSync(METRICS_FILE, JSON.stringify({ ...metrics, updatedAt: new Date().toISOString() }, null, 2)); }
  catch { /* best-effort */ }
}
setInterval(flushMetrics, 10_000);

// ── Retry helper ─────────────────────────────────────────────────────────────
async function connectWithRetry<T>(
  name:        string,
  factory:     () => Promise<T>,
  maxAttempts  = 20,
  delayMs      = 5_000,
): Promise<T> {
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await factory();
    } catch (err) {
      const wait = Math.min(delayMs * attempt, 30_000); // Incremental backoff
      console.warn(`[ingester] ${name} not ready (attempt ${attempt}/${maxAttempts}) — retrying in ${wait / 1_000}s...`);
      if (attempt === maxAttempts) throw err;
      await new Promise(r => setTimeout(r, wait));
    }
  }
  throw new Error(`${name} never became available`);
}

// ── Batch flush — commit-after-durable-write semantics ──────────────────────
// ClickHouse is now the PRIMARY (and only) message store.
// If CH write fails, this function THROWS so the caller does NOT commit
// the Kafka offset → at-least-once delivery is preserved.
async function flushBatch(
  clickhouse: ClickHouseClient,
  messages:   RawMessage[],
): Promise<void> {
  if (messages.length === 0) return;
  const start = Date.now();

  try {
    await clickhouseWrite(clickhouse, messages);
  } catch (err) {
    metrics.chErrors++;
    logSampled('ch-write', 'error', `[ingester] ClickHouse write FAILED (${metrics.chErrors} total) — offset NOT committed:`, err);
    reportError(clickhouse, 'clickhouse_write', 'error', `ClickHouse write failed (${metrics.chErrors} total)`, err);
    throw err; // propagate — caller must NOT commit offset
  }

  metrics.msgsProcessed += messages.length;
  metrics.batchesFlushed++;

  const elapsed = Date.now() - start;
  const mps     = Math.round(messages.length / (elapsed / 1_000));
  if (metrics.batchesFlushed % 10 === 0)
    console.log(`[ingester] Flushed ${messages.length} msgs in ${elapsed}ms (~${mps} msg/s)`);
}

async function run(): Promise<void> {
  console.log('[ingester] Waiting for ClickHouse...');

  const clickhouse = await connectWithRetry('ClickHouse', createClickHouseClient);

  console.log('[ingester] ClickHouse ready — connecting to Kafka...');

  const kafka = new Kafka({
    clientId: 'senneo-ingester',
    brokers:  KAFKA_BROKERS.split(','),
    retry:    { retries: 10, initialRetryTime: 300, factor: 2 },
  });

  // Ensure DLQ topic exists
  const admin = kafka.admin();
  try {
    await admin.connect();
    const existing = await admin.listTopics();
    if (!existing.includes(KAFKA_TOPIC)) {
      await admin.createTopics({
        topics: [{
          topic:             KAFKA_TOPIC,
          numPartitions:     TARGET_TOPIC_PARTITIONS,
          replicationFactor: KAFKA_REPLICATION_FACTOR,
        }],
      });
      console.log(`[ingester] Topic '${KAFKA_TOPIC}' created (${TARGET_TOPIC_PARTITIONS} partitions)`);
    } else {
      const metadata = await admin.fetchTopicMetadata({ topics: [KAFKA_TOPIC] });
      const currentPartitions = metadata.topics.find(item => item.name === KAFKA_TOPIC)?.partitions.length ?? 0;
      if (currentPartitions > 0 && currentPartitions < TARGET_TOPIC_PARTITIONS) {
        await admin.createPartitions({
          topicPartitions: [{ topic: KAFKA_TOPIC, count: TARGET_TOPIC_PARTITIONS }],
        });
        console.log(`[ingester] Topic '${KAFKA_TOPIC}' partitions increased (${currentPartitions} -> ${TARGET_TOPIC_PARTITIONS})`);
      }
    }
    if (!existing.includes(KAFKA_DLQ_TOPIC)) {
      await admin.createTopics({
        topics: [{
          topic:             KAFKA_DLQ_TOPIC,
          numPartitions:     1,
          replicationFactor: KAFKA_REPLICATION_FACTOR,
          configEntries: [{ name: 'retention.ms', value: String(30 * 24 * 3600 * 1000) }], // 30d
        }],
      });
      console.log(`[ingester] DLQ topic '${KAFKA_DLQ_TOPIC}' created`);
    }
  } catch (err) {
    console.warn('[ingester] Could not create DLQ topic (non-fatal):', err);
  } finally {
    await admin.disconnect();
  }

  // DLQ producer — sends unparseable messages for later inspection
  const dlqProducer = kafka.producer();
  await dlqProducer.connect();

  const consumer: Consumer = kafka.consumer({
    groupId:          KAFKA_GROUP,
    maxBytes:         CONSUMER_MAX_BYTES,
    maxBytesPerPartition: CONSUMER_MAX_BYTES_PER_PARTITION,
    minBytes:         CONSUMER_MIN_BYTES,
    maxWaitTimeInMs:  CONSUMER_MAX_WAIT_TIME_MS,
    sessionTimeout:   90_000,
    heartbeatInterval: 10_000,
  });

  await consumer.connect();
  await consumer.subscribe({ topic: KAFKA_TOPIC, fromBeginning: true });
  console.log(`[ingester] Subscribed to '${KAFKA_TOPIC}' | DLQ: '${KAFKA_DLQ_TOPIC}'`);

  await consumer.run({
    // P0 FIX: Disable auto-resolve — we resolve offsets ONLY after durable write
    eachBatchAutoResolve: false,
    autoCommitInterval:   5_000,
    autoCommitThreshold:  BATCH_FLUSH_SIZE,
    partitionsConsumedConcurrently: PARTITIONS_CONSUMED_CONCURRENTLY,

    eachBatch: async ({
      batch,
      resolveOffset,
      heartbeat,
      commitOffsetsIfNecessary,
    }: EachBatchPayload) => {
      const messages: RawMessage[] = [];
      const offsets: string[] = [];           // Track offsets per message in current sub-batch
      const dlqMessages: { key: string; value: string }[] = [];
      let lastDlqOffset: string | null = null;

      for (const kafkaMsg of batch.messages) {
        if (!kafkaMsg.value) continue;

        const raw = kafkaMsg.value.toString();
        let parsed: RawMessage | null = null;

        try {
          parsed = JSON.parse(raw) as RawMessage;
          // Basic schema validation
          if (!parsed.messageId || !parsed.channelId || !parsed.guildId || !parsed.authorId) {
            throw new Error('Missing required fields');
          }
        } catch (err) {
          console.warn(`[ingester] Unparseable message → DLQ: ${(err as Error).message}`);
          reportError(clickhouse, 'dlq_parse', 'warn', `Unparseable message → DLQ: ${(err as Error).message}`, err);
          dlqMessages.push({
            key:   kafkaMsg.key?.toString() ?? '',
            value: JSON.stringify({ error: (err as Error).message, raw: raw.slice(0, 500), offset: kafkaMsg.offset }),
          });
          metrics.msgsFailedDlq++;
          // DLQ messages are safe to resolve — they are intentionally skipped
          lastDlqOffset = kafkaMsg.offset;
          continue;
        }

        messages.push(parsed);
        offsets.push(kafkaMsg.offset);

        if (messages.length >= BATCH_FLUSH_SIZE) {
          const subBatch  = messages.splice(0, BATCH_FLUSH_SIZE);
          const subOffset = offsets.splice(0, BATCH_FLUSH_SIZE);

          // flushBatch throws on CH failure → offset NOT committed → at-least-once
          await flushBatch(clickhouse, subBatch);

          // Only resolve after durable write succeeds
          resolveOffset(subOffset[subOffset.length - 1]);
          await heartbeat();
          await commitOffsetsIfNecessary();
        }
      }

      // Flush remaining messages
      if (messages.length > 0) {
        await flushBatch(clickhouse, messages);
        resolveOffset(offsets[offsets.length - 1]);
      } else if (lastDlqOffset) {
        // If only DLQ messages remained, resolve up to last DLQ offset
        resolveOffset(lastDlqOffset);
      }

      // Send failed messages to DLQ in one batch
      if (dlqMessages.length > 0) {
        try {
          await dlqProducer.send({ topic: KAFKA_DLQ_TOPIC, messages: dlqMessages });
        } catch (err) {
          console.error('[ingester] Failed to write to DLQ:', err);
        }
      }
    },
  });

  const shutdown = async () => {
    console.log('[ingester] Shutting down...');
    flushMetrics();
    await consumer.disconnect();
    await dlqProducer.disconnect();
    console.log('[ingester] Stopped');
    process.exit(0);
  };
  process.on('SIGINT',  shutdown);
  process.on('SIGTERM', shutdown);
}

run().catch(err => {
  console.error('[ingester] Fatal:', err);
  process.exit(1);
});
